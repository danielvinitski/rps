#pragma once
int main(int argc, char *argv[]);
int checkFileExist(ifstream& player1File, ifstream& player2File);